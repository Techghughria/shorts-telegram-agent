from pathlib import Path
import shutil
import subprocess

def ensure_ffmpeg():
    if not shutil.which("ffmpeg"):
        raise FileNotFoundError("FFmpeg not found. Install it with: sudo apt install ffmpeg")

def probe_duration(path: Path) -> float:
    ensure_ffmpeg()
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        check=True, capture_output=True, text=True
    )
    return float(result.stdout.strip())

def build_short(source: Path, output: Path, seconds: int, music: Path | None, music_volume: float):
    ensure_ffmpeg()
    output.parent.mkdir(parents=True, exist_ok=True)
    if music:
        # Scale/crop to 9:16; mix source audio with selected music.
        filter_complex = (
            "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,"
            "crop=1080:1920,setsar=1[v];"
            f"[0:a]volume=0.25[a0];[1:a]volume={music_volume}[a1];"
            "[a0][a1]amix=inputs=2:duration=first:dropout_transition=2[a]"
        )
        cmd = ["ffmpeg", "-y", "-i", str(source), "-stream_loop", "-1", "-i", str(music),
               "-t", str(seconds), "-filter_complex", filter_complex,
               "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "medium",
               "-crf", "22", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(output)]
    else:
        cmd = ["ffmpeg", "-y", "-i", str(source), "-t", str(seconds),
               "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1",
               "-c:v", "libx264", "-preset", "medium", "-crf", "22",
               "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(output)]
    subprocess.run(cmd, check=True, capture_output=True, text=True)
